Модуль треугольника
===================

.. automodule:: Triangle
   :members: