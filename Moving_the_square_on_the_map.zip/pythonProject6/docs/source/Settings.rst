Модуль настроек
===============

.. automodule:: Settings
   :members: