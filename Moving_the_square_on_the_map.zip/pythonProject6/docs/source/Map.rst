Модуль карты
============

.. automodule:: Map
   :members: