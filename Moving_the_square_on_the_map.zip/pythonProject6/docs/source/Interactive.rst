Модуль интерактива
==================

.. automodule:: Interactive
   :members: