.. Перемещение квадрата по карте documentation master file, created by
   sphinx-quickstart on Mon May 27 19:09:49 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Перемещение квадрата по карте's documentation!
=========================================================

.. toctree::
   :maxdepth: 2
   :caption: Структура проекта "Перемещение квадрата по карте":

   main
   Square
   Map
   Interactive
   Triangle
   Bullet
   Draw
   Bfs
   Settings



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
