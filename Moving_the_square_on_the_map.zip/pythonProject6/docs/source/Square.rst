Модуль квадрата
===============

.. automodule:: Square
   :members: