Модуль пули
===========

.. automodule:: Bullet
   :members: