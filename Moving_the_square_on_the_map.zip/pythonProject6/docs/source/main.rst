Запуск проекта
==============

main-функция
------------

.. autofunction:: main.main