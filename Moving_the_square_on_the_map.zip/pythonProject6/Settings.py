from abc import ABC, abstractmethod
import pygame

class Object1(ABC):
    """Абстрактный класс для объекта 1."""

    @abstractmethod
    def movement(self) -> None:
        """Абстрактный метод для выполнения движения объекта."""
        pass

    @abstractmethod
    def draw(self, screen: pygame.Surface) -> None:
        """Абстрактный метод для отрисовки объекта на экране.

        Args:
            screen (pygame.Surface): Поверхность экрана для отрисовки.
        """
        pass

    @abstractmethod
    def check_event(self, event) -> None:
        """Абстрактный метод для обработки событий.

        Args:
            event: Событие, которое нужно обработать.
        """
        pass

    @abstractmethod
    def get_rect(self) -> pygame.Rect:
        """Абстрактный метод для получения прямоугольника объекта.

        Returns:
            pygame.Rect: Прямоугольник объекта.
        """
        pass

    @abstractmethod
    def actions_in_the_event_of_a_collision(self) -> None:
        """Абстрактный метод для действий в случае коллизии."""
        pass

    @abstractmethod
    def get_time(self) -> pygame.time:
        """Абстрактный метод для получения времени.

        Returns:
            pygame.time: время создания объекта"""
        pass

    @abstractmethod
    def get_is_dead(self) -> bool:
        """Абстрактный метод для получения информации о том, мертв ли объект.

        Returns:
            bool: True, если объект мертв, иначе False.
        """
        pass

    @abstractmethod
    def get_centre(self) -> tuple:
        """Абстрактный метод для получения координат центра объекта.

        Returns:
            tuple: Координаты центра объекта.
        """
        pass

# Глобальные переменные
width, height = 800, 450
halfWidth = width // 2
halfHeight = height // 2
max_depth = 800
black = (0, 0, 0)
white = (255, 255, 255)
FPS = 60

