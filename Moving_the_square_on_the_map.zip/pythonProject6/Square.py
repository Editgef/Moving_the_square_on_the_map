from Settings import *
from Map import collisions_walls, map_width, map_height, tile
import math


class Square(Object1):
    def __init__(self, player_pos: tuple) -> None:
        """Инициализирует объект квадрата.

        Args:
            player_pos (tuple): Начальная позиция квадрата.
        """
        self.__name = "Square"
        self.__colour = white
        self.__angle = 0
        self.__side = 50
        self.__ox = player_pos[0] + tile // 2
        self.__oy = player_pos[1] + tile // 2
        self.__isDead = False
        self.__hp = 100
        self.__kills = 0

        self.__horizontal_move_speed = 0
        self.__vertical_move_speed = 0
        self.__speed_max = 10
        self.__time = pygame.time.get_ticks()
        self.__speed_up = 0.5
        self.__speed_down = 0.1
        self.__reloading = 10 * 60

        self.__direction = {
            pygame.K_w: False, pygame.K_a: False,
            pygame.K_s: False, pygame.K_d: False
        }
        self.__low_hp_sound = pygame.mixer.Sound("sound/mixkit-negative-guitar-tone-2324.wav")

    def get_direction_keys(self) -> list:
        """Возвращает клавиши, представляющие направления движения.

        Returns:
            list: Список клавиш, представляющих направления движения.
        """
        return list(self.__direction.keys())

    def check_event(self, event: pygame.event) -> None:
        """Проверяет и обрабатывает события для квадрата.

        Args:
            event (pygame.event): Событие для обработки.
        """
        if event.type == pygame.KEYDOWN:
            self.__direction[event.key] = True
        elif event.type == pygame.KEYUP:
            self.__direction[event.key] = False

    def movement(self) -> None:
        """Обновляет позицию квадрата на основе пользовательского ввода."""
        self.__horizontal_move_speed += self.__speed_up * (self.__direction[pygame.K_d] - self.__direction[pygame.K_a])

        if not (self.__direction[pygame.K_d] or self.__direction[pygame.K_a]):
            if abs(self.__horizontal_move_speed) < self.__speed_down:
                self.__horizontal_move_speed = 0
            elif self.__horizontal_move_speed > 0:
                self.__horizontal_move_speed -= self.__speed_down
            else:
                self.__horizontal_move_speed += self.__speed_down
        elif self.__horizontal_move_speed > self.__speed_max:
            self.__horizontal_move_speed = self.__speed_max
        elif self.__horizontal_move_speed < -self.__speed_max:
            self.__horizontal_move_speed = -self.__speed_max

        self.__vertical_move_speed += self.__speed_up * (self.__direction[pygame.K_s] - self.__direction[pygame.K_w])

        if not (self.__direction[pygame.K_s] or self.__direction[pygame.K_w]):
            if abs(self.__vertical_move_speed) < self.__speed_down:
                self.__vertical_move_speed = 0
            elif self.__vertical_move_speed > 0:
                self.__vertical_move_speed -= self.__speed_down
            else:
                self.__vertical_move_speed += self.__speed_down
        elif self.__vertical_move_speed > self.__speed_max:
            self.__vertical_move_speed = self.__speed_max
        elif self.__vertical_move_speed < -self.__speed_max:
            self.__vertical_move_speed = -self.__speed_max

        self.detect_collision(self.__horizontal_move_speed, self.__vertical_move_speed)

    def detect_collision(self, dx: int, dy: int) -> None:
        """Обнаруживает столкновение и обновляет позицию квадрата соответственно.

        Args:
            dx (int): Изменение по x-координате.
            dy (int): Изменение по y-координате.
        """
        min_x, min_y, max_x, max_y = tile, tile, map_width - tile, map_height - tile
        self.__ox += dx
        self.__oy += dy
        radius = self.__side // 2
        if self.__ox - radius < min_x:
            self.__ox = radius + min_x

        if self.__oy - radius < min_y:
            self.__oy = radius + min_y

        if self.__ox + radius > max_x:
            self.__ox = max_x - radius

        if self.__oy + radius > max_y:
            self.__oy = max_y - radius

        ball = pygame.Rect((0, 0), (radius * 2, radius * 2))
        ball.center = int(self.__ox), int(self.__oy)
        hit_indexes = ball.collidelistall(collisions_walls)
        if len(hit_indexes):
            for hitIndex in hit_indexes:
                hit_rect = collisions_walls[hitIndex]
                dx = self.__ox - hit_rect.centerx
                dy = self.__oy - hit_rect.centery
                if abs(dx) > abs(dy):
                    if dx < 0:
                        self.__ox = max(hit_rect.left - radius, radius + min_x)
                        hit_rect.left = int(self.__ox) + radius
                    else:
                        self.__ox = min(hit_rect.right + radius, max_x - radius)
                        hit_rect.right = int(self.__ox) - radius
                else:
                    if dy < 0:
                        self.__oy = max(hit_rect.top - radius, radius + min_y)
                        hit_rect.top = int(self.__oy) + radius
                    else:
                        self.__oy = min(hit_rect.bottom + radius, max_y - radius)
                        hit_rect.bottom = int(self.__oy) - radius
                    self.__oy = hit_rect.top - radius if dy < 0 else hit_rect.bottom + radius

    def draw(self, screen: pygame.Surface) -> None:
        """Рисует квадрат на экране.

        Args:
            screen (pygame.Surface): Поверхность, на которой рисуется квадрат.
        """
        pygame.draw.rect(screen, self.__colour, (self.__ox - self.__side // 2,
                                                 self.__oy - self.__side // 2, self.__side, self.__side))

        offset_x = min(max(self.__ox - self.__side // 2 - width // 2, 0), map_width - width)
        offset_y = min(max(self.__oy - self.__side // 2 - height // 2, 0), map_height - height)
        x, y = pygame.mouse.get_pos()
        x += offset_x
        y += offset_y
        pygame.draw.line(screen, self.__colour, (self.__ox, self.__oy), (x, y))
        dx = x - self.__ox
        dy = y - self.__oy
        self.__angle = math.atan2(dx, dy)

    def get_x(self) -> int:
        """Получает x-координату квадрата.

        Returns:
            int: x-координата квадрата.
        """
        return self.__ox

    def get_y(self) -> int:
        """Получает y-координату квадрата.

        Returns:
            int: y-координата квадрата.
        """
        return self.__oy

    def get_centre(self) -> tuple:
        """Получает центральные координаты квадрата.

        Returns:
            tuple: Центральные координаты квадрата.
        """
        return self.__ox, self.__oy

    def get_angle(self) -> [int, float]:
        """Получает угол квадрата.

        Returns:
            [int, float]: Угол квадрата.
        """
        return self.__angle

    def get_time(self) -> pygame.time:
        """Получает время создания квадрата.

        Returns:
            pygame.time: Время создания квадрата.
        """
        return self.__time

    def set_time(self, time: pygame.time) -> None:
        """Устанавливает время создания квадрата.

        Args:
            time (pygame.time): Время создания для установки.
        """
        self.__time = time

    def get_is_dead(self) -> bool:
        """Проверяет, мертв ли квадрат.

        Returns:
            bool: True, если квадрат мертв, иначе False.
        """
        return self.__isDead

    def set_is_dead(self) -> None:
        """Устанавливает квадрат как мертвый."""
        self.__isDead = True

    def get_rect(self) -> pygame.Rect:
        """Получает прямоугольник, представляющий квадрат.

        Returns:
            pygame.Rect: Прямоугольник, представляющий квадрат.
        """
        return pygame.Rect(self.__ox - self.__side // 2, self.__oy - self.__side // 2, self.__side, self.__side)

    def get_reloading(self) -> int:
        """Получает время перезарядки квадрата.

        Returns:
            int: Время перезарядки квадрата.
        """
        return self.__reloading

    def take_damage(self) -> None:
        """Уменьшает количество очков здоровья квадрата на 10."""
        self.__hp -= 10
        if self.__hp == 50:
            self.__low_hp_sound.play()
        if self.__hp == 0:
            self.__isDead = True

    def actions_in_the_event_of_a_collision(self) -> None:
        """Выполняет действия при столкновении квадрата с другими объектами."""
        self.take_damage()

    def get_kills(self) -> int:
        """Получает количество убийств квадрата.

        Returns:
            int: Количество убийств квадрата.
        """
        return self.__kills


    def set_kills(self, kills: int) -> None:
        """Устанавливает количество убийств квадрата.

        Args:
            kills (int): Количество убийств для установки.
        """
        self.__kills = kills

    def get_args(self) -> tuple:
        """Возвращает аргументы квадрата.

        Returns:
            tuple: Кортеж аргументов квадрата.
        """
        return self.get_centre()

    def set_centre(self, ox: [int, float], oy: [int, float]) -> None:
        """Устанавливает центральные координаты квадрата.

        Args:
            ox (int, float): x-координата центра.
            oy (int, float): y-координата центра.
        """
        self.__ox, self.__oy = ox, oy

    def get_name(self) -> str:
        """Возвращает имя квадрата.

        Returns:
            str: Имя квадрата.
        """
        return self.__name

