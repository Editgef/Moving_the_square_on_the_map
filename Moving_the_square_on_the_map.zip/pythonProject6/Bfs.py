from collections import deque
from Map import all_map, graph, tile


def find_way(x1: int, y1: int, x2: int, y2: int) -> list:
    """Находит путь от (x1, y1) до (x2, y2) с использованием BFS.

    Args:
        x1 (int): Начальная x-координата в пикселях.
        y1 (int): Начальная y-координата в пикселях.
        x2 (int): Целевая x-координата в пикселях.
        y2 (int): Целевая y-координата в пикселях.

    Returns:
        list: Список кортежей, представляющих путь в декартной системе координат.
    """
    x, y, to_x, to_y = int(x1 / tile), int(y1 / tile), int(x2 / tile), int(y2 / tile)
    start = (x, y)
    goal = start
    visited = {start: None}
    mouse_pos = to_x, to_y

    # Проверка, что целевая позиция не заблокирована
    if mouse_pos and not all_map[to_y][to_x]:
        queue, visited = bfs(start, mouse_pos)
        goal = mouse_pos

    answer = []
    path_head, path_segment = goal, goal

    # Восстановление пути от цели к старту
    while path_segment and path_segment in visited:
        answer.append((path_segment[0] * tile + tile // 2, path_segment[1] * tile + tile // 2))
        path_segment = visited[path_segment]

    # Исключение начальной позиции из пути
    answer = answer[1:]
    return answer[::-1]

def bfs(start: tuple, goal: tuple) -> tuple:
    """Выполняет BFS для поиска кратчайшего пути от старта к цели.

    Args:
        start (tuple): Начальная позиция (x, y) в координатах сетки.
        goal (tuple): Целевая позиция (x, y) в координатах сетки.

    Returns:
        tuple: Очередь и словарь посещенных узлов с путями.
    """
    queue = deque([start])
    visited = {start: None}

    while queue:
        cur_node = queue.popleft()
        if cur_node == goal:
            break

        next_nodes = graph[cur_node]
        for next_node in next_nodes:
            if next_node not in visited:
                queue.append(next_node)
                visited[next_node] = cur_node

    return queue, visited

