import math
from Map import map_width, map_height, tile, collisions_walls
import pygame.draw
from Settings import Object1, white


class Bullet(Object1):
    """Представляет объект пули в игре.

    Attributes:
        _count (int): Переменная класса для подсчета количества экземпляров пуль.
    """

    _count = 0

    def __init__(self, x: int, y: int, angle: [float, int]) -> None:
        """Инициализирует пулю с позицией и углом.

        Args:
            x (int): Начальная координата x пули.
            y (int): Начальная координата y пули.
            angle ([float, int]): Угол траектории пули.
        """
        self.__is_dead = False
        self.__radius = 7
        self.__ox = x
        self.__oy = y
        self.__time = pygame.time.get_ticks()
        self.__time_a_live = 5 * 60 * 60
        self.__colour = white
        self.__v = pygame.math.Vector2(math.sin(angle), math.cos(angle))
        self.__speed: float = 12
        self.__speed_down = 0.05
        Bullet._count += 1

    def movement(self) -> None:
        """Обновляет позицию пули и обрабатывает столкновения."""
        min_x, min_y, max_x, max_y = tile, tile, map_width - tile, map_height - tile
        self.__ox += self.__v[0] * self.__speed
        self.__oy += self.__v[1] * self.__speed

        self.__speed -= self.__speed_down
        self.__speed = max(0.0, self.__speed)

        if self.__ox - self.__radius < min_x:
            self.__ox = self.__radius + min_x
            self.__v[0] = -self.__v[0]
        if self.__oy - self.__radius < min_y:
            self.__oy = self.__radius + min_y
            self.__v[1] = -self.__v[1]
        if self.__ox + self.__radius > max_x:
            self.__ox = max_x - self.__radius
            self.__v[0] = -self.__v[0]
        if self.__oy + self.__radius > max_y:
            self.__oy = max_y - self.__radius
            self.__v[1] = -self.__v[1]

        ball = pygame.Rect((0, 0), (self.__radius * 2, self.__radius * 2))
        ball.center = int(self.__ox), int(self.__oy)
        hit_indexes = ball.collidelistall(collisions_walls)
        if len(hit_indexes):
            for hit_index in hit_indexes:
                hit_rect = collisions_walls[hit_index]
                dx = self.__ox - hit_rect.centerx
                dy = self.__oy - hit_rect.centery
                if abs(dx) > abs(dy):
                    if dx < 0:
                        self.__ox = max(hit_rect.left - self.__radius, self.__radius + min_x)
                        hit_rect.left = int(self.__ox) + self.__radius
                    else:
                        self.__ox = min(hit_rect.right + self.__radius, max_x - self.__radius)
                        hit_rect.right = int(self.__ox) - self.__radius
                    if (dx < 0 and self.__v[0] > 0) or (dx > 0 and self.__v[0] < 0):
                        self.__v.reflect_ip(pygame.math.Vector2(1, 0))
                else:
                    if dy < 0:
                        self.__oy = max(hit_rect.top - self.__radius, self.__radius + min_y)
                        hit_rect.top = int(self.__oy) + self.__radius
                    else:
                        self.__oy = min(hit_rect.bottom + self.__radius, max_y - self.__radius)
                        hit_rect.bottom = int(self.__oy) - self.__radius
                    self.__oy = hit_rect.top - self.__radius if dy < 0 else hit_rect.bottom + self.__radius
                    if (dy < 0 and self.__v[1] > 0) or (dy > 0 and self.__v[1] < 0):
                        self.__v.reflect_ip(pygame.math.Vector2(0, 1))

    def draw(self, screen: pygame.Surface) -> None:
        """Рисует пулю на экране.

        Args:
            screen (pygame.Surface): Поверхность для рисования пули.
        """
        pygame.draw.circle(screen, self.__colour, (round(self.__ox), round(self.__oy)), self.__radius)

    def check_event(self, event: pygame.event) -> None:
        """Обрабатывает события для пули.

        Args:
            event (pygame.event): Событие для обработки.
        """
        pass

    @staticmethod
    def get_count() -> int:
        """Возвращает текущее количество экземпляров пуль.

        Returns:
            int: Количество экземпляров пуль.
        """
        return Bullet._count

    def __del__(self) -> None:
        """Уменьшает счетчик пуль при удалении экземпляра."""
        Bullet._count -= 1

    def get_rect(self) -> pygame.Rect:
        """Возвращает прямоугольник, представляющий пулю.

        Returns:
            pygame.Rect: Прямоугольник пули.
        """
        return pygame.Rect(self.__ox - self.__radius, self.__oy - self.__radius, self.__radius * 2, self.__radius * 2)

    def get_is_dead(self) -> bool:
        """Проверяет, мертва ли пуля.

        Returns:
            bool: True, если пуля мертва, иначе False.
        """
        return self.__is_dead

    def set_is_dead(self, is_dead: bool) -> None:
        """Устанавливает статус мертвой пули.

        Args:
            is_dead (bool): Статус мертвой пули.
        """
        self.__is_dead = is_dead

    def actions_in_the_event_of_a_collision(self) -> None:
        """Определяет действия в случае столкновения."""
        self.__is_dead = True

    def get_time(self) -> pygame.time:
        """Возвращает время создания пули.

        Returns:
            pygame.time: Время создания пули.
        """
        return self.__time

    def get_time_alive(self) -> int:
        """Возвращает продолжительность жизни пули.

        Returns:
            int: Продолжительность жизни пули.
        """
        return self.__time_a_live

    def is_live(self) -> bool:
        """Проверяет, жива ли пуля на основе ее времени жизни.

        Returns:
            bool: True, если пуля еще жива, иначе False.
        """
        return pygame.time.get_ticks() - self.__time <= self.__time_a_live

    def get_centre(self) -> tuple:
        """Возвращает координаты центра пули.

        Returns:
            tuple: Координаты центра пули.
        """
        return self.__ox, self.__oy

    def disappearance_check(self) -> None:
        """Проверяет, должна ли пуля исчезнуть на основе ее времени жизни."""
        if pygame.time.get_ticks() - self.__time > self.__time_a_live:
            self.__is_dead = True
            self.__del__()

