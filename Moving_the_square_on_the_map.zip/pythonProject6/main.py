import sys
from Interactive import *
from Triangle import *
from Map import player_pos

def main():
    """Основная функция программы."""
    pygame.init()

    # Создание окна отображения
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption('Перемещение квадрата по карте')

    # Создание поверхности карты
    map_surface = pygame.Surface((map_width, map_height))
    map_surface.fill(black)

    # Создание квадрата и инициализация часов
    square = Square(player_pos)
    clock = pygame.time.Clock()

    # Создание объектов для отрисовки и взаимодействия
    drawing = Draw(screen, map_surface, clock)
    interactive = Interactive(square, drawing, [
        Triangle(square, [(800, 160), (1720, 160)]),
        Triangle(square, [(1720, 160), (800, 160)]),
        Triangle(square, [(1120, 480), (1400, 480)]),
        Triangle(square, [(1400, 480), (1400, 1040)]),
        Triangle(square, [(1120, 1040), (1400, 1040)]),
        Triangle(square, [(1120, 480), (1120, 1040)]),
        Triangle(square, [(160, 160), (480, 160)]),
        Triangle(square, [(160, 400), (160, 160)]),
        Triangle(square, [(480, 160), (480, 400)]),
        Triangle(square, [(480, 400), (160, 400)]),
    ])

    # Воспроизведение музыки и отображение меню
    Interactive.play_music()
    drawing.menu(interactive)
    pygame.mouse.set_visible(False)

    running = True
    while running:
        # Обработка событий
        interactive.check_events()

        # Определение смещения для отображения части карты
        offset_x = min(max(square.get_x() - width // 2, 0), map_width - width)
        offset_y = min(max(square.get_y() - height // 2, 0), map_height - height)
        screen.blit(map_surface, (0, 0), (offset_x, offset_y, width, height))
        pygame.display.flip()

        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
