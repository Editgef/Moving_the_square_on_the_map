from Bullet import *
from Triangle import *
from Draw import Draw
import json
import os


class Interactive:
    """Класс, представляющий взаимодействие объектов в игре.

    Attributes:
        __drawing (Draw): Объект для рисования игрового мира.
        __square (Square): Объект квадрата.
        __list_triangles (list): Список объектов треугольников.
        __count_Triangles (int): Количество треугольников в игре.
        __list_bullets (list): Список объектов пуль.
        __shotSound (pygame.mixer.Sound): Звук выстрела.
        __game_over_sound (pygame.mixer.Sound): Звук проигрыша.
        __win_sound (pygame.mixer.Sound): Звук победы.
        __collision_sound (pygame.mixer.Sound): Звук столкновения.
    """

    def __init__(self, square: Square, drawing: Draw, list_triangles: list) -> None:
        """Инициализирует объект Interactive с квадратом, рисованием и списком треугольников.

        Args:
            square (Square): Объект квадрата.
            drawing (Draw): Объект рисования.
            list_triangles (list): Список объектов треугольников.
        """
        self.__drawing = drawing
        self.__square = square
        self.__list_triangles = list_triangles.copy()
        self.__count_Triangles = len(list_triangles)
        self.__list_bullets = []

        self.__shotSound = pygame.mixer.Sound('sound/mixkit-arcade-mechanical-bling-210.wav')
        self.__game_over_sound = pygame.mixer.Sound("sound/J3YL2BH-videogame-bloop-game-over.mp3")
        self.__win_sound = pygame.mixer.Sound("sound/mixkit-winning-a-coin-video-game-2069.wav")
        self.__collision_sound = pygame.mixer.Sound("sound/mixkit-player-jumping-in-a-video-game-2043.wav")

    def check_events(self) -> None:
        """Проверяет и обрабатывает события, такие как выход и стрельба.

        Обрабатывает события пользователя и системы, обновляет объекты мира,
        проверяет столкновения, исчезновение объектов, обновляет списки и проверяет условия победы.
        """
        get_all_world_objects = self.get_all_world_objects()
        if self.__square.get_is_dead():
            exit()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.shoot(self.__square, self.__square.get_angle())

            for obj in get_all_world_objects:
                obj.check_event(event)

        self.__drawing.world(get_all_world_objects)

        for obj in self.__list_triangles:
            if obj.get_saw_square():
                self.shoot(obj, obj.get_angel_to_square())

        for obj in get_all_world_objects:
            obj.movement()

        self.hit_check()
        self.disappearance_check()
        self.update_lists()
        self.check_win()

    def hit_check(self) -> None:
        """Проверяет и обрабатывает столкновения между объектами.

        Проверяет столкновения между пулями и треугольниками, а также пулями и квадратом.
        """
        object_collusion_sheet = [obj.get_rect() for obj in self.__list_bullets]
        for index_obj in range(len(self.__list_triangles) - 1, -1, -1):
            if self.__list_triangles[index_obj].get_rect().collidelist(object_collusion_sheet) != -1:
                self.__collision_sound.play()
                self.__list_triangles[index_obj].actions_in_the_event_of_a_collision()

        if self.__square.get_rect().collidelist(object_collusion_sheet) != -1:
            self.__collision_sound.play()
            self.__square.actions_in_the_event_of_a_collision()

        object_collusion_sheet1 = [obj.get_rect() for obj in self.__list_triangles]
        object_collusion_sheet1.append(self.__square.get_rect())
        for index_obj in range(len(self.__list_bullets) - 1, -1, -1):
            if self.__list_bullets[index_obj].get_rect().collidelist(object_collusion_sheet1) != -1:
                self.__list_bullets[index_obj].actions_in_the_event_of_a_collision()

    def disappearance_check(self) -> None:
        """Проверяет и обрабатывает исчезновение объектов, таких как пули.

        Удаляет пули, которые больше не присутствуют в игровом мире.
        """
        for index_obj in range(len(self.__list_bullets) - 1, -1, -1):
            obj = self.__list_bullets[index_obj]
            obj.disappearance_check()

    def shoot(self, from_object: [Square, Triangle], angle: [float, int]) -> None:
        """Обрабатывает логику стрельбы для квадратов и треугольников.

        Args:
            from_object (Square or Triangle): Объект, который стреляет.
            angle (float or int): Угол, под которым объект стреляет.
        """
        if pygame.time.get_ticks() - from_object.get_time() > from_object.get_reloading():
            self.__shotSound.play()
            from_object.set_time(pygame.time.get_ticks())
            x, y = from_object.get_centre()
            x += math.sin(angle) * tile * 1.5
            y += math.cos(angle) * tile * 1.5
            bullet = Bullet(x, y, angle)
            self.__list_bullets.append(bullet)

    def check_win(self) -> None:
        """Проверяет условия победы и обрабатывает логику конца игры.

        Если квадрат достигает необходимого количества убийств, запускается последовательность победы.
        Если квадрат мертв, запускается последовательность проигрыша.
        """
        if self.__square.get_kills() >= self.__count_Triangles:
            self.write_file()
            pygame.mixer.music.stop()
            self.__win_sound.play()
            while True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        exit()
                self.__drawing.win()
        elif self.__square.get_is_dead():
            self.write_file()
            pygame.mixer.music.stop()
            self.__game_over_sound.play()
            while True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        exit()
                self.__drawing.losing()

    @staticmethod
    def play_music() -> None:
        """Воспроизводит фоновую музыку для игры.

        Инициализирует микшер и воспроизводит фоновую музыку в цикле.
        """
        pygame.mixer.pre_init(44100, -16, 2, 2048)
        pygame.mixer.init()
        pygame.mixer.music.load("sound/2020-03-22_-_A_Bit_Of_Hope_-_David_Fesliyan.mp3")
        pygame.mixer.music.play(10)

    def write_file(self) -> None:
        """Записывает текущее состояние игры в файл.

        Сохраняет координаты квадрата и соответствующие данные состояния игры в JSON файл.
        """
        dict_coordinates = {"SquareCoordinates": self.__square.get_args()}

        with open("coordinates.json", "w") as file:
            json.dump(dict_coordinates, file)

    def load_file(self) -> None:
        """Загружает состояние игры из файла.

        Читает координаты квадрата и соответствующие данные состояния игры из JSON файла и обновляет состояние игры.
        """
        filename = "coordinates.json"
        if os.path.isfile(filename):
            with open("coordinates.json", "r") as file:
                dict_coordinates = json.load(file)
            self.__square.set_centre(*dict_coordinates["SquareCoordinates"])

    def get_all_world_objects(self) -> list:
        """Получает все объекты мира.

        Returns:
            list: Список всех объектов в игровом мире, включая квадрат, треугольники и пули.
        """
        get_all_world_objects = [self.__square]
        for obj in self.__list_triangles:
            get_all_world_objects.append(obj)
        for obj in self.__list_bullets:
            get_all_world_objects.append(obj)
        return get_all_world_objects

    def update_lists(self) -> None:
        """Обновляет списки пуль и треугольников.

        Удаляет мертвые пули и треугольники из их соответствующих списков.
        """
        for indexObj in range(len(self.__list_bullets) - 1, -1, -1):
            if self.__list_bullets[indexObj].get_is_dead():
                self.__list_bullets.pop(indexObj)
        for indexObj in range(len(self.__list_triangles) - 1, -1, -1):
            if self.__list_triangles[indexObj].get_is_dead():
                self.__list_triangles.pop(indexObj)
