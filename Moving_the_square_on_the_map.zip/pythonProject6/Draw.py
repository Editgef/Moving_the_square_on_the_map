from Map import world_map
from Square import *
import sys
from random import randrange


class Draw:
    """Класс для управления отрисовкой элементов игры.

    Attributes:
        __screen (pygame.Surface): Основная поверхность для отображения.
        __map_surface (pygame.Surface): Поверхность для рисования карты.
        __clock (pygame.time.Clock): Игровые часы для управления обновлением экрана.
        __menu_trigger (bool): Флаг, управляющий отображением меню.
        __font_win (pygame.font.Font): Шрифт для отображения текста победы и проигрыша.
    """

    def __init__(self,
                 screen: pygame.Surface,
                 map_surface: pygame.Surface,
                 clock: pygame.time.Clock
                 ) -> None:
        """Инициализирует класс для рисования.

        Args:
            screen (pygame.Surface): Основная поверхность для отображения.
            map_surface (pygame.Surface): Поверхность для рисования карты.
            clock (pygame.time.Clock): Игровые часы.
        """
        self.__screen = screen
        self.__map_surface = map_surface
        self.__clock = clock
        self.__menu_trigger = True
        self.__font_win = pygame.font.Font('font/font.ttf', 100)

    def world(self, world_objects: list) -> None:
        """Рисует мир, включая карту и все объекты мира.

        Args:
            world_objects (list): Список всех объектов, которые нужно нарисовать на карте.
        """
        self.__map_surface.fill((0, 0, 0))

        for x, y in world_map:
            pygame.draw.rect(self.__map_surface, (255, 255, 255), (x, y, tile, tile))

        for obj in world_objects:
            obj.draw(self.__map_surface)

    def win(self) -> None:
        """Отображает экран победы."""
        render = self.__font_win.render('YOU WIN!!!', 1, (randrange(40, 120), 0, 0))
        rect = pygame.Rect(0, 0, 1000, 300)
        rect.center = halfWidth, halfHeight
        pygame.draw.rect(self.__screen, white, rect, border_radius=50)
        self.__screen.blit(render, (rect.centerx - 350, rect.centery - 90))
        pygame.display.flip()
        self.__clock.tick(15)

    def losing(self) -> None:
        """Отображает экран проигрыша."""
        render = self.__font_win.render('you lost...', 1, (randrange(40, 120), 0, 0))
        rect = pygame.Rect(0, 0, 1000, 300)
        rect.center = halfWidth, halfHeight
        pygame.draw.rect(self.__screen, white, rect, border_radius=50)
        self.__screen.blit(render, (rect.centerx - 350, rect.centery - 90))
        pygame.display.flip()
        self.__clock.tick(15)

    def menu(self, interactive) -> None:
        """Отображает главное меню и обрабатывает взаимодействия с меню.

        Args:
            interactive: Объект для загрузки данных игры.
        """
        while self.__menu_trigger:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            self.__screen.fill((0, 0, 0))

            button_font = pygame.font.Font('font/font.ttf', 40)

            start_text = button_font.render('START', 1, pygame.Color('lightgray'))
            button_start = pygame.Rect(0, 0, 300, 80)
            button_start.center = halfWidth, halfHeight - 40

            exit_text = button_font.render('EXIT', 1, pygame.Color('lightgray'))
            button_exit = pygame.Rect(0, 0, 300, 80)
            button_exit.center = halfWidth, halfHeight + 50

            load_save_text = button_font.render('LOAD SAVE', 1, pygame.Color('lightgray'))
            button_load_save = pygame.Rect(0, 0, 300, 80)
            button_load_save.center = halfWidth, halfHeight + 140

            pygame.draw.rect(self.__screen, white, button_start, width=6)
            self.__screen.blit(start_text, (button_start.centerx - 75, button_start.centery - 20))

            pygame.draw.rect(self.__screen, white, button_exit, width=6)
            self.__screen.blit(exit_text, (button_exit.centerx - 55, button_exit.centery - 20))

            pygame.draw.rect(self.__screen, white, button_load_save, width=6)
            self.__screen.blit(load_save_text, (button_load_save.centerx - 130, button_load_save.centery - 20))

            label = self.__font_win.render('Square', 1, (255, 255, 255))
            self.__screen.blit(label, (200, 0))

            mouse_pos = pygame.mouse.get_pos()
            mouse_click = pygame.mouse.get_pressed()
            if button_start.collidepoint(mouse_pos):
                pygame.draw.rect(self.__screen, white, button_start)
                self.__screen.blit(start_text, (button_start.centerx - 75, button_start.centery - 20))
                if mouse_click[0]:
                    self.__menu_trigger = False
            elif button_exit.collidepoint(mouse_pos):
                pygame.draw.rect(self.__screen, white, button_exit)
                self.__screen.blit(exit_text, (button_exit.centerx - 55, button_exit.centery - 20))
                if mouse_click[0]:
                    pygame.quit()
                    sys.exit()
            elif button_load_save.collidepoint(mouse_pos):
                pygame.draw.rect(self.__screen, white, button_load_save)
                self.__screen.blit(load_save_text, (button_load_save.centerx - 130, button_load_save.centery - 20))
                if mouse_click[0]:
                    interactive.load_file()
                    self.__menu_trigger = False

            pygame.display.flip()
            self.__clock.tick(20)
