from Bfs import *
from Square import *
from Map import world_map


class Triangle(Object1):
    _count = 0

    def __init__(self, square: Square, route: list) -> None:
        """Инициализирует треугольник с целевым квадратом и маршрутом.

        Args:
            square (Square): Целевой квадрат.
            route (list): Маршрут, по которому движется треугольник.
        """
        self.__name = f"Triangle{Triangle._count}"
        self.__isDead = False
        self.__hp = 100
        self.__side = 50
        self.__saw_square = False
        self.__ox = route[0][0]
        self.__oy = route[0][1]
        self.__square = square
        self.__speed = 4
        self.__route = route.copy()
        self.__pathway = None
        self.__colour = white
        self.__time = pygame.time.get_ticks()
        self.__reloading = 10 * 60

        self.__sprite = pygame.image.load("image/5734a6bbecfb6154a5ab4e43.png").convert_alpha()
        self.__sprite = pygame.transform.smoothscale(self.__sprite, (self.__side, self.__side))

        Triangle._count += 1

    def movement(self) -> None:
        """Обновляет позицию треугольника и управляет логикой его движения.

        Перемещает треугольник по маршруту или к квадрату, если он его видит.
        """
        player_x, player_y = self.__square.get_centre()
        distance_player = math.sqrt((player_x - self.__ox) ** 2 + (player_y - self.__oy) ** 2)
        point_x, point_y = self.__route[0]

        distance_point = math.sqrt((point_x - self.__ox) ** 2 + (point_y - self.__oy) ** 2)
        if distance_player > tile * 2:
            if distance_point < self.__side * 1.5:
                self.__route.append(self.__route.pop(0))

            if self.__saw_square:
                way = find_way(self.__ox, self.__oy, *self.__square.get_centre())
            else:
                way = find_way(self.__ox, self.__oy, *self.__route[0])
            if way:
                dx, dy = way[0][0] - self.__ox, way[0][1] - self.__oy
                distance_point = math.sqrt(dx ** 2 + dy ** 2)

                if distance_point < self.__side:
                    way.append(way.pop(0))
                    dx, dy = way[0][0] - self.__ox, way[0][1] - self.__oy

                a = math.atan2(dy, dx)
                self.__ox += self.__speed * math.cos(a)
                self.__oy += self.__speed * math.sin(a)

    def draw(self, screen: pygame.Surface) -> None:
        """Рисует треугольник на экране.

        Args:
            screen (pygame.Surface): Поверхность, на которой рисуется треугольник.
        """
        screen.blit(self.__sprite, (self.__ox - self.__side // 2, self.__oy - self.__side // 2))

    def ray_casting(self) -> bool:
        """Выполняет трассировку лучей для обнаружения квадрата.

        Returns:
            bool: True, если квадрат обнаружен, иначе False.
        """
        ox, oy = self.__ox, self.__oy
        to_x, to_y = self.__square.get_centre()

        dx, dy = ox - to_x, oy - to_y

        a = math.atan2(dy, dx)
        sin_a = math.sin(a)
        cos_a = math.cos(a)
        for depth in range(max_depth):
            x = ox - depth * cos_a
            y = oy - depth * sin_a
            if self.__square.get_rect().collidepoint(x, y):
                return True
            if (x // tile * tile, y // tile * tile) in world_map or math.sqrt((x - ox) ** 2 + (y - oy) ** 2) > 8 * tile:
                return False
        return False

    def check_event(self, event: pygame.event) -> None:
        """Обрабатывает события для треугольника.

        Args:
            event (pygame.event): Событие для обработки.
        """
        if self.ray_casting():
            self.__saw_square = True
            self.__speed = 8

    def get_rect(self) -> pygame.Rect:
        """Получает прямоугольник, представляющий треугольник.

        Returns:
            pygame.Rect: Прямоугольник треугольника.
        """
        return pygame.Rect(self.__ox - self.__side // 2, self.__oy - self.__side // 2, self.__side, self.__side)

    def get_time(self) -> int:
        """Получает время создания треугольника.

        Returns:
            int: Время создания треугольника.
        """
        return self.__time

    def set_time(self, time: int) -> None:
        """Устанавливает время создания треугольника.

        Args:
            time (int): Время создания для установки.
        """
        self.__time = time

    def get_centre(self) -> tuple:
        """Получает центральные координаты треугольника.

        Returns:
            tuple: Центральные координаты треугольника.
        """
        return self.__ox, self.__oy

    def get_reloading(self) -> int:
        """Получает время перезарядки треугольника.

        Returns:
            int: Время перезарядки треугольника.
        """
        return self.__reloading

    def get_is_dead(self) -> bool:
        """Проверяет, мертв ли треугольник.

        Returns:
            bool: True, если треугольник мертв, иначе False.
        """
        return self.__isDead

    def set_is_dead(self, is_dead: bool) -> None:
        """Устанавливает статус смерти треугольника.

        Args:
            is_dead (bool): Статус смерти для установки.
        """
        self.__isDead = is_dead

    def actions_in_the_event_of_a_collision(self) -> None:
        """Определяет действия в случае столкновения.

        Увеличивает количество убийств квадрата и устанавливает статус треугольника как мертвый.
        """
        if not self.__isDead:
            self.__square.set_kills(self.__square.get_kills() + 1)
        self.__isDead = True

    def get_saw_square(self) -> bool:
        """Проверяет, видел ли треугольник квадрат.

        Returns:
            bool: True, если треугольник видел квадрат, иначе False.
        """
        return self.__saw_square

    def get_angel_to_square(self) -> float:
        """Получает угол к квадрату.

        Returns:
            float: Угол к квадрату.
        """
        dx = self.__square.get_x() - self.__ox
        dy = self.__square.get_y() - self.__oy
        angle = math.atan2(dx, dy)
        return angle

    @staticmethod
    def get_count() -> int:
        """Получает количество экземпляров треугольников.

        Returns:
            int: Количество экземпляров треугольников.
        """
        return Triangle._count

    def get_name(self) -> str:
        """Получает имя треугольника.

        Returns:
            str: Имя треугольника.
        """
        return self.__name

